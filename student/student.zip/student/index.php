<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];


// Assuming you have the username stored in session
$username = strtoupper($_SESSION['username']); // e.g., 'user1'

// Construct the profile picture URL
$profilePicUrl = "https://university-student-photos.s3.ap-south-1.amazonaws.com/049/student_photos%2F{$username}.JPG";
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Student Profile</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<link rel="stylesheet" href="styles.css">
 
</head>
<body>
  <nav class="navbar">
    <div class="nav-logo">Student Portal</div>
    <div class="nav-items" id="nav-items">
  
      <button class="btn btn-primary" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasRight" aria-controls="offcanvasRight">Notification</button>

<div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasRight" aria-labelledby="offcanvasRightLabel">
  <div class="offcanvas-header">
    <h5 id="offcanvasRightLabel">Offcanvas right</h5>
    <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
  </div>
  <div class="offcanvas-body">
    <?php
  $receiver_id = $_SESSION['user_id'];

$stmt = $conn->prepare("SELECT u.email AS sender_email, n.message, n.created_at
                        FROM notifications n
                        JOIN users u ON n.sender_id = u.id
                        WHERE n.receiver_id = ?
                        ORDER BY n.created_at DESC");
$stmt->bind_param("i", $receiver_id);
$stmt->execute();
$result = $stmt->get_result();

echo "<h2>Your Notifications:</h2>";
while ($row = $result->fetch_assoc()) {
    echo "<div style='border: 1px solid #000000; padding: 10px; margin: 10px 0; background-color: #f9f9f9; color: #000;'>";
    echo "<strong>From:</strong> " . htmlspecialchars($row['sender_email']) . "<br>";
    echo "<strong>Message:</strong> " . htmlspecialchars($row['message']) . "<br>";
    echo "<em>" . $row['created_at'] . "</em>";
    echo "</div>";
}
?>
  </div>
</div>

    </div>
    <div class="nav-toggle" onclick="toggleNav()">☰</div>
  </nav>
  
  <section class="profile-section">
    <h1>Student Info</h1>
    <div class="profile-container">
      <div class="profile-pic">
       
        <img src="<?= $profilePicUrl ?>" alt="Mentee Profile Picture" class="profile-image" id="profile-image">
      </div>

      <table id="student-info">
        <tr><th>Name</th><td id="name"></td></tr>
        <tr><th>USN</th><td id="usn"></td></tr>
        <tr><th>Date of Birth</th><td id="dob"></td></tr>
        <tr><th>SSLC Marks</th><td id="sslc"></td></tr>
        <tr><th>PUC/DIP Marks</th><td id="puc"></td></tr>
        <tr><th>Email</th><td id="email"></td></tr>
        <tr><th>Place of Stay</th><td id="place"></td></tr>
        <tr><th>Hobbies</th><td id="hobbies"></td></tr>
      </table>
    </div>
  </section>

  <section class="family-section">
    <h2>Family Info</h2>
    <table id="family-info">
      <tr><th>Father's Name</th><td id="fatherName"></td>
          <th>Mother's Name</th><td id="motherName"></td></tr>
      <tr><th>Father's Occupation</th><td id="fatherJob"></td>
          <th>Mother's Occupation</th><td id="motherJob"></td></tr>
      <tr><th>Address</th><td colspan="3" id="familyAddress"></td></tr>
      <tr><th>Father's Phone</th><td id="fatherPhone"></td>
          <th>Mother's Phone</th><td id="motherPhone"></td></tr>
    </table>
  </section>

  <form action="dashboard.php" method="post">
    <button type="submit">Go to dashboard</button>
</form>



  <script src="main1.js"></script>
</body>
</html>